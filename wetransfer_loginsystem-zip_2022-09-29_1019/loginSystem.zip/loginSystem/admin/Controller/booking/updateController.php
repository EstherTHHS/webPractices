<?php

session_start();

include "../../Model/dbConnection.php";

if (isset($_POST["updateBooking"])) {

    $date = $_POST["date"];
    $time = $_POST["time"];
    $doctor = $_POST["doctor"];
    $dep = $_POST["dep"];
    $feeling = $_POST["feeling"];
    $id = $_POST["id"];
    $status = $_POST["status"];

    $sql = $pdo->prepare(
        "UPDATE booking SET 
            date=:date,
            time=:time,
            doctor=:doctor,
            department=:dep,
            feeling=:feeling,
            status=:status,
            update_date=:updateDate
        WHERE id=:id"
    );

    $sql->bindValue(":date", $date);
    $sql->bindValue(":time", $time);
    $sql->bindValue(":doctor", $doctor);
    $sql->bindValue(":dep", $dep);
    $sql->bindValue(":feeling", $feeling);
    $sql->bindValue(":status", $status);
    $sql->bindValue(":updateDate", date("Y/m/d"));
    $sql->bindValue(":id", $id);

    $sql->execute();

    header("Location: ../../View/dashboard.php");
} else {
    header("Location: ../View/login.php");
}
