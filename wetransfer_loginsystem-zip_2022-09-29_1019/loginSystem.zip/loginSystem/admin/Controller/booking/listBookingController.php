<?php

include "../Model/dbConnection.php";


$sql = $pdo->prepare("SELECT * FROM booking");
$sql->execute();
$patientBookingList = $sql->fetchAll(PDO::FETCH_ASSOC);

?>